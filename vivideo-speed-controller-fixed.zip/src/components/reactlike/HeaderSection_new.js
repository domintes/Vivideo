// Deprecated: this file is not used. Keeping a minimal stub to avoid formatter/parser errors.
export default function HeaderSection() {
  return null;
}
